import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;

public class AppointmentTest {

    @Test
    public void testAppointmentCreation() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000); // 1 day in the future
        Appointment appointment = new Appointment("app1", futureDate, "Appointment Description");
        assertEquals("app1", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Appointment Description", appointment.getDescription());
    }

    @Test
    public void testAppointmentIdNotNullOrEmpty() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, futureDate, "Appointment Description"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345678901", futureDate, "Appointment Description"));
    }

    @Test
    public void testInvalidAppointmentDate() {
        Date pastDate = new Date(System.currentTimeMillis() - 86400000); // 1 day in the past
        assertThrows(IllegalArgumentException.class, () -> new Appointment("app1", pastDate, "Appointment Description"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("app1", null, "Appointment Description"));
    }

    @Test
    public void testInvalidDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("app1", futureDate, null));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("app1", futureDate, "This description is too long and should throw an exception when attempted."));
    }
}
