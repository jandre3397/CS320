import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    public void testTaskCreation() {
        Task task = new Task("task1", "Task Name", "Task Description");
        assertEquals("task1", task.getTaskId());
        assertEquals("Task Name", task.getName());
        assertEquals("Task Description", task.getDescription());
    }

    @Test
    public void testTaskIdNotNullOrEmpty() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Task Name", "Task Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Task Name", "Task Description"));
    }

    @Test
    public void testInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> new Task("task1", null, "Task Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("task1", "TaskNameTooLongForTheLimit", "Task Description"));
    }

    @Test
    public void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> new Task("task1", "Task Name", null));
        assertThrows(IllegalArgumentException.class, () -> new Task("task1", "Task Name", "This description is too long and should throw an exception when attempted."));
    }
}
