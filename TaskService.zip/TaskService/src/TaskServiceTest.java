import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

    @Test
    public void testAddTask() {
        TaskService service = new TaskService();
        Task task = new Task("task1", "Task Name", "Task Description");
        service.addTask(task);
        assertThrows(IllegalArgumentException.class, () -> service.addTask(task));
    }

    @Test
    public void testDeleteTask() {
        TaskService service = new TaskService();
        Task task = new Task("task1", "Task Name", "Task Description");
        service.addTask(task);
        service.deleteTask("task1");
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("task2"));
    }

    @Test
    public void testUpdateTaskName() {
        TaskService service = new TaskService();
        Task task = new Task("task1", "Task Name", "Task Description");
        service.addTask(task);
        service.updateTaskName("task1", "New Task Name");
        assertEquals("New Task Name", task.getName());
    }

    @Test
    public void testUpdateTaskDescription() {
        TaskService service = new TaskService();
        Task task = new Task("task1", "Task Name", "Task Description");
        service.addTask(task);
        service.updateTaskDescription("task1", "New Task Description");
        assertEquals("New Task Description", task.getDescription());
    }
}
